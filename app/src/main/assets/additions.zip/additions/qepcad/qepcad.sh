installdir=/data/data/jp.yhonda/files; export installdir
qe=$installdir/additions/qepcad ; export qe
cat $installdir/x86
case $? in
  0) binname=$qe/bin/qepcad.x86;;
  1) binname=$qe/bin/qepcad;;
esac
$binname < $installdir/qepcad_input.txt > $installdir/qepcad_output.txt

